# final_project
Non-complete package for the final project for: ENPM809Y Fall 2021

- The `doc` folder contains the instructions.
- The `script` folder contains install.bash to install required packages.
