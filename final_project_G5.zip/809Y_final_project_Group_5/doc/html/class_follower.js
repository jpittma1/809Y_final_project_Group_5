var class_follower =
[
    [ "Follower", "class_follower.html#a6870e654b7cc901944ead12870a6b107", null ],
    [ "~Follower", "class_follower.html#a1dd55289af5ded7a57a2874c5477c33d", null ],
    [ "compute_expected_final_yaw", "class_follower.html#a5573bec72ce4aed99706213154849b65", null ],
    [ "compute_yaw_deg", "class_follower.html#ac988cad87474cb64ef3be7fe197d90a7", null ],
    [ "compute_yaw_rad", "class_follower.html#abde593631e6549062d77fb2169a17c66", null ],
    [ "convert_rad_to_deg", "class_follower.html#a670f07466502e1020514d6ba6b928553", null ],
    [ "drive_straight", "class_follower.html#ad4d1ce6f43ce65c0aa5a560247ca55ad", null ],
    [ "go_to_goal", "class_follower.html#a08ab05cb32f0e6653939163dd22f344a", null ],
    [ "publish_velocities", "class_follower.html#aaae1600959a929c269d557d9c09ba777", null ],
    [ "rotate", "class_follower.html#abf8ec0da50295140bf750d30906a726b", null ],
    [ "setup_goals", "class_follower.html#a9ff755f0d81808c372bfcaac0a45471c", null ],
    [ "stop", "class_follower.html#a84c17a75630c27bea4f401c8ab8e45b2", null ],
    [ "m_fid", "class_follower.html#a350054bbd7659d493cccc4b4ad9bc460", null ],
    [ "m_goal_count", "class_follower.html#af53c7dcd8b5a99111bdfe0c8dd2015cf", null ],
    [ "m_posit", "class_follower.html#a6d4e1ebbe79cc8af601d53cba7aeb30a", null ],
    [ "m_test", "class_follower.html#a64e365d54197c51a8d1f777900b09647", null ],
    [ "temp_x", "class_follower.html#ad27859970acb7f208f6b34e511673b26", null ],
    [ "temp_y", "class_follower.html#ac5ed416e67251cffb81b99a685341bff", null ]
];