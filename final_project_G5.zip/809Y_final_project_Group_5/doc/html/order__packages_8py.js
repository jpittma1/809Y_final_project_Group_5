var order__packages_8py =
[
    [ "blacklisted_packages", "order__packages_8py.html#a29ea913f00c5a0e81d3c7688e7375507", null ],
    [ "source_root_dir", "order__packages_8py.html#aff4fd297841de7fbddc2c0c33a6bab21", null ],
    [ "underlay_workspaces", "order__packages_8py.html#a11d102ff09fd2977b9075c4c722015d2", null ],
    [ "whitelisted_packages", "order__packages_8py.html#a84450a73e77dbf3689293b97dcb697a4", null ]
];