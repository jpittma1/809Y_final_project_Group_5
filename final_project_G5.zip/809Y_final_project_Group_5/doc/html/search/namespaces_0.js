var searchData=
[
  ['_5fsetup_5futil',['_setup_util',['../namespace__setup__util.html',1,'']]]
];
