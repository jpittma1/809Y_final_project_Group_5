var searchData=
[
  ['setup_5fgoals',['setup_goals',['../class_follower.html#a9ff755f0d81808c372bfcaac0a45471c',1,'Follower']]],
  ['stop',['stop',['../class_explorer.html#a0e4a623ff30d1886cc9f57ec081c527f',1,'Explorer::stop()'],['../class_follower.html#a84c17a75630c27bea4f401c8ab8e45b2',1,'Follower::stop()']]]
];
