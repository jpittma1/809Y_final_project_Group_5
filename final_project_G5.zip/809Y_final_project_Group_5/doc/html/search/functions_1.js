var searchData=
[
  ['comment',['comment',['../namespace__setup__util.html#abe8c95c4cfe8b1374dacd5f91d984353',1,'_setup_util']]],
  ['compute_5fexpected_5ffinal_5fyaw',['compute_expected_final_yaw',['../class_explorer.html#a02c37b93448ed474f1bf0d03e2758ca2',1,'Explorer::compute_expected_final_yaw()'],['../class_follower.html#a5573bec72ce4aed99706213154849b65',1,'Follower::compute_expected_final_yaw()']]],
  ['compute_5fyaw_5fdeg',['compute_yaw_deg',['../class_explorer.html#a670cdffdb8c3173c300590cfc45ab6d2',1,'Explorer::compute_yaw_deg()'],['../class_follower.html#ac988cad87474cb64ef3be7fe197d90a7',1,'Follower::compute_yaw_deg()']]],
  ['compute_5fyaw_5frad',['compute_yaw_rad',['../class_explorer.html#ac5b91cd64189a60ffe62535cb5bc093a',1,'Explorer::compute_yaw_rad()'],['../class_follower.html#abde593631e6549062d77fb2169a17c66',1,'Follower::compute_yaw_rad()']]],
  ['convert_5frad_5fto_5fdeg',['convert_rad_to_deg',['../class_explorer.html#ac3a5c9368647dd9d2c36d12497bd889e',1,'Explorer::convert_rad_to_deg()'],['../class_follower.html#a670f07466502e1020514d6ba6b928553',1,'Follower::convert_rad_to_deg()']]]
];
