var searchData=
[
  ['path_5fto_5fadd_5fsuffix',['PATH_TO_ADD_SUFFIX',['../namespace__setup__util.html#a7de27b8c021c888c6288a885f1e9afa9',1,'_setup_util']]],
  ['pkg_5fconfig_5flibraries_5fwith_5fprefix',['PKG_CONFIG_LIBRARIES_WITH_PREFIX',['../namespacepkg.html#a433e30cecb4a0123a7c4b384d168e336',1,'pkg']]],
  ['project_5fcatkin_5fdepends',['PROJECT_CATKIN_DEPENDS',['../namespacepkg.html#a17c18447fad253ee1c0d76deec88028c',1,'pkg']]],
  ['project_5fname',['PROJECT_NAME',['../namespacepkg.html#a7dfbe99257c26f5e4a3a5483995d9ddc',1,'pkg']]],
  ['project_5fpkg_5fconfig_5finclude_5fdirs',['PROJECT_PKG_CONFIG_INCLUDE_DIRS',['../namespacepkg.html#a2760bf8266ff58da440f65ee91b203ab',1,'pkg']]],
  ['project_5fspace_5fdir',['PROJECT_SPACE_DIR',['../namespacepkg.html#a3f0f1b4bc03c596525e025539ca4332f',1,'pkg']]],
  ['project_5fversion',['PROJECT_VERSION',['../namespacepkg.html#ab1037914b9286bb61855131c06149648',1,'pkg']]],
  ['python_5fpath',['python_path',['../namespacegenerate__cached__setup.html#a72579fd01529a79bab20d99291889d3f',1,'generate_cached_setup']]]
];
