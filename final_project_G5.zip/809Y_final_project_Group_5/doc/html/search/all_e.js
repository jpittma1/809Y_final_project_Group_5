var searchData=
[
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['rollback_5fenv_5fvariables',['rollback_env_variables',['../namespace__setup__util.html#af3030db6102b5aa35cd354a2fb6cca03',1,'_setup_util']]],
  ['rotate',['rotate',['../class_explorer.html#ac8e3a980fd3929734fb3a4b0b2e0a7e0',1,'Explorer::rotate()'],['../class_follower.html#abf8ec0da50295140bf750d30906a726b',1,'Follower::rotate()']]]
];
