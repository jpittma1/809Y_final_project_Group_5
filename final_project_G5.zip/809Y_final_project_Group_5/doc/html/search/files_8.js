var searchData=
[
  ['pkg_2edevelspace_2econtext_2epc_2epy',['pkg.develspace.context.pc.py',['../pkg_8develspace_8context_8pc_8py.html',1,'']]],
  ['pkg_2einstallspace_2econtext_2epc_2epy',['pkg.installspace.context.pc.py',['../pkg_8installspace_8context_8pc_8py.html',1,'']]]
];
