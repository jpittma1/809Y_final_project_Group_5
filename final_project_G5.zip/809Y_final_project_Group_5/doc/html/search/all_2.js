var searchData=
[
  ['base_5fpath',['base_path',['../namespace__setup__util.html#a83d25140acd7788bbcb95843fe38e639',1,'_setup_util']]],
  ['blacklisted_5fpackages',['blacklisted_packages',['../namespaceorder__packages.html#a29ea913f00c5a0e81d3c7688e7375507',1,'order_packages']]]
];
