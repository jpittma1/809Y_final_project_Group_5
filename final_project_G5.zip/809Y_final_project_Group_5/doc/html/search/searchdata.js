var indexSectionsWithContent =
{
  0: "_abcdefghilmoprstuw~",
  1: "aef",
  2: "_gop",
  3: "_acefgmopr",
  4: "acdefgmprs~",
  5: "abcefgilmopstuw",
  6: "m",
  7: "acdhps",
  8: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Macros",
  8: "Pages"
};

