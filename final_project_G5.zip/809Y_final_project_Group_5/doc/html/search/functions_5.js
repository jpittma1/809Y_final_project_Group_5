var searchData=
[
  ['get_5fgoals',['get_goals',['../class_explorer.html#a847e3ad2e7233d493a8dcfdd7139cb58',1,'Explorer']]],
  ['go_5fto_5fgoal',['go_to_goal',['../class_explorer.html#aa1e259feaac1114adb0f24588428e8ef',1,'Explorer::go_to_goal()'],['../class_follower.html#a08ab05cb32f0e6653939163dd22f344a',1,'Follower::go_to_goal()']]]
];
