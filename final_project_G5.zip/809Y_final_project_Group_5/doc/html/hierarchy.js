var hierarchy =
[
    [ "Bot_Controller", "class_bot___controller.html", [
      [ "Explorer", "class_explorer.html", null ],
      [ "Follower", "class_follower.html", null ]
    ] ],
    [ "BotActionServer", "class_bot_action_server.html", null ]
];