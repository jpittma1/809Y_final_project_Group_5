var pkg_8develspace_8context_8pc_8py =
[
    [ "CATKIN_PACKAGE_PREFIX", "pkg_8develspace_8context_8pc_8py.html#ae26c7a5a06b7d738f4d210ca449e6bee", null ],
    [ "PKG_CONFIG_LIBRARIES_WITH_PREFIX", "pkg_8develspace_8context_8pc_8py.html#a433e30cecb4a0123a7c4b384d168e336", null ],
    [ "PROJECT_CATKIN_DEPENDS", "pkg_8develspace_8context_8pc_8py.html#a17c18447fad253ee1c0d76deec88028c", null ],
    [ "PROJECT_NAME", "pkg_8develspace_8context_8pc_8py.html#a7dfbe99257c26f5e4a3a5483995d9ddc", null ],
    [ "PROJECT_PKG_CONFIG_INCLUDE_DIRS", "pkg_8develspace_8context_8pc_8py.html#a2760bf8266ff58da440f65ee91b203ab", null ],
    [ "PROJECT_SPACE_DIR", "pkg_8develspace_8context_8pc_8py.html#a3f0f1b4bc03c596525e025539ca4332f", null ],
    [ "PROJECT_VERSION", "pkg_8develspace_8context_8pc_8py.html#ab1037914b9286bb61855131c06149648", null ]
];