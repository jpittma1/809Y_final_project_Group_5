var namespaces =
[
    [ "_setup_util", "namespace__setup__util.html", null ],
    [ "generate_cached_setup", "namespacegenerate__cached__setup.html", null ],
    [ "order_packages", "namespaceorder__packages.html", null ],
    [ "pkg", "namespacepkg.html", null ]
];