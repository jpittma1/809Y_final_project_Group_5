var class_explorer =
[
    [ "Explorer", "class_explorer.html#aafe6b7c3b9c2e24815aa14a731f31890", null ],
    [ "~Explorer", "class_explorer.html#aa1b0a71e92e003e9162a5ba99d843392", null ],
    [ "compute_expected_final_yaw", "class_explorer.html#a02c37b93448ed474f1bf0d03e2758ca2", null ],
    [ "compute_yaw_deg", "class_explorer.html#a670cdffdb8c3173c300590cfc45ab6d2", null ],
    [ "compute_yaw_rad", "class_explorer.html#ac5b91cd64189a60ffe62535cb5bc093a", null ],
    [ "convert_rad_to_deg", "class_explorer.html#ac3a5c9368647dd9d2c36d12497bd889e", null ],
    [ "drive_straight", "class_explorer.html#ab4ca9f16c48a60fc4d0e426b6fd9e9a0", null ],
    [ "get_goals", "class_explorer.html#a847e3ad2e7233d493a8dcfdd7139cb58", null ],
    [ "go_to_goal", "class_explorer.html#aa1e259feaac1114adb0f24588428e8ef", null ],
    [ "m_move", "class_explorer.html#ace304ef65547f4a3ff6458d934c54e87", null ],
    [ "move_next_loc", "class_explorer.html#a2b0c1e46e1a17e99f4156edf5a93b691", null ],
    [ "publish_velocities", "class_explorer.html#a8ffef25585ef957b9df4407366723787", null ],
    [ "rotate", "class_explorer.html#ac8e3a980fd3929734fb3a4b0b2e0a7e0", null ],
    [ "stop", "class_explorer.html#a0e4a623ff30d1886cc9f57ec081c527f", null ],
    [ "goal_list", "class_explorer.html#acda1856f421dfe836f39de446415b969", null ],
    [ "m_velocity_publisher", "class_explorer.html#aee857cd646f2ce6eb7e017a67e90bcdf", null ],
    [ "start_place", "class_explorer.html#af1aee46522a58db39d3643f2138c76fa", null ]
];