var explorer_8cpp =
[
    [ "get_goals", "explorer_8cpp.html#a61450d29adf96573b7eec19cb2fa8156", null ]
];